package org.example;

public class MyThread2 extends Thread{

  Display display;
  String name;
  public MyThread2(Display display, String name) {
    this.display = display;
    this.name = name;
  };

  /*@Override
  public void run() {
    display.display(name);
  }*/

  MyThread2() {}
  @Override
  public void run() {
    System.out.println("child thread value " + MyThread.tl.get());
  }
}

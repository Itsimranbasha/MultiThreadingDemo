package org.example;

import java.sql.SQLOutput;
import java.util.concurrent.locks.ReentrantLock;

public class Display {

  public Display() {
  }

  ReentrantLock reentrantLock = new ReentrantLock();
  public void display(String name) {
    reentrantLock.lock();
    reentrantLock.lock();
    reentrantLock.lock();
    System.out.println(reentrantLock.isFair());
    try {
      for (int i = 0; i < 10; i++) {
        System.out.print("Good Morning: ");
        Thread.sleep(1000);
        System.out.println(name);
      }
    } catch (InterruptedException e) {
      throw new RuntimeException(e);
    }
    reentrantLock.unlock();
  }

  public static synchronized void displayNum() {
    for (int i=0;i<10;i++) {
      System.out.println(i);
      try {
        Thread.sleep(1000);
      } catch (InterruptedException e) {
        throw new RuntimeException(e);
      }
    }
  }

  public static void displayChar() {
    for (int i=65;i<75;i++) {
      System.out.println((char)i);
      try {
        Thread.sleep(1000);
      } catch (InterruptedException e) {
        throw new RuntimeException(e);
      }
    }
  }
}

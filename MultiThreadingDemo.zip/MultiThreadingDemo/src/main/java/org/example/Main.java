package org.example;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Main {
  public static void main(String[] args) throws InterruptedException, ExecutionException {

    ThreadGroup threadGroup = Thread.currentThread().getThreadGroup().getParent();
    int activeCount = threadGroup.activeGroupCount();
    System.out.println("activeGroupCount-" + activeCount);

    ThreadGroup[] threadList = new ThreadGroup[2];
    threadGroup.enumerate(threadList);
    for(ThreadGroup group : threadList) {
      System.out.println(group.getName());
    }

    ThreadGroup threadGroup1 = Thread.currentThread().getThreadGroup();
    System.out.println(threadGroup1.getParent().getMaxPriority());
    Thread.currentThread().getThreadGroup().getParent().setMaxPriority(6);
    System.out.println(Thread.currentThread().getPriority());
    System.out.println(threadGroup1.getParent().getMaxPriority());

    MyRunnable runnable = new MyRunnable();

    Thread thread1 = new Thread(() -> System.out.println("lambda expression"));
    Thread thread2 = new Thread(new Runnable() {
      @Override
      public void run() {
        System.out.println("anonymours class");
      }
    });
    thread1.start();
    thread2.start();

    MyThread.mt = Thread.currentThread();

    MyThread thread = new MyThread();
    try {
      for (int i = 0; i < 10; i++) {
        System.out.println("Main Thread");
        thread.join();
      }
    } catch(InterruptedException e) {
      System.out.println("thread interrupted");
    }

    MyThread thr1 = new MyThread();
    thr1.start();
    thr1.setPriority(10);
    thr1.interrupt();
    for (int i = 0; i < 10; i++) {
      System.out.println("Main Thread");
    }

    Display d = new Display();
    MyThread th1 = new MyThread(d, "kohli");
    MyThread2 th2 = new MyThread2(d, "mahendra");
    th1.start();
    th2.start();

    MyThread t = new MyThread();
    t.start();
    synchronized (t) {
      System.out.println("Main thread calls wait method");
      t.wait();
      System.out.println("Main thread receives notification from other thread ");
      System.out.println(t.total);
    }

    MyRunnable[] jobs = {
        new MyRunnable("imran"),
        new MyRunnable("sania"),
        new MyRunnable("maqbool"),
        new MyRunnable("jayanth"),
        new MyRunnable("jilan"),
        new MyRunnable("vardhan")
    };

    ExecutorService service = Executors.newFixedThreadPool(3);
    for (MyRunnable job : jobs) {
      service.submit(job);
    }
    service.shutdown();

    MyCallable[] jobs1 = {
        new MyCallable(10),
        new MyCallable(20),
        new MyCallable(30),
        new MyCallable(40),
        new MyCallable(50),
        new MyCallable(60)
    };

    ExecutorService service1 = Executors.newFixedThreadPool(3);
    for (MyCallable job : jobs1) {
      Future r = service.submit(job);
      System.out.println(r.get());
    }
    service.shutdown();

    MyThread t1 = new MyThread("MyThread-1");
    MyThread t2 = new MyThread("MyThread-2");
    MyThread t3 = new MyThread("MyThread-3");
    MyThread t4 = new MyThread("MyThread-4");

    t1.start();
    t2.start();
    t3.start();
    t4.start();
  }
}
package org.example;

public class MyThread extends Thread{

  Display display;
  String name;
  static Thread mt;
  int total = 0;

  public MyThread() {
  }

  public MyThread(Display display, String name) {
    this.display = display;
    this.name = name;
  }

  public MyThread(Display display) {
    this.display = display;
  }

  public MyThread(String name) {
    this.name = name;
  }

  /*public void start() {
    super.start();
    System.out.println("manual start method");
  }*/

  /*@Override
  public void run() {
    System.out.println("child thread starts execution");
    for(int i=1;i<=100;i++) {
      total = total + i;
    }
    synchronized (this) {
      this.notify();
      System.out.println("child thread gives the notification");
    }
  }*/

  /*@Override
  public void run() {
    try {
    for(int i=0;i<10;i++) {
      System.out.println("Child Thread ");
      mt.join();
    } } catch (InterruptedException e) {
      System.out.println("thread interrupted");
    }
  }*/

  /*static Integer threadId = 0;
  private static ThreadLocal tl = new ThreadLocal(){
    protected Integer initialValue() {
      return ++threadId;
    }
  };

  @Override
  public void run() {
    System.out.println(Thread.currentThread().getName() + "exectuing with thread id: " + tl.get());
  }*/

  public static InheritableThreadLocal tl = new InheritableThreadLocal()
  {
    public Object childValue(Object pp) {
      return "cc";
    }
  };
  public void run() {
    tl.set("pp");
    System.out.println("Parent thread value " + tl.get());
    MyThread2 ct = new MyThread2();
    ct.start();
  }
}
